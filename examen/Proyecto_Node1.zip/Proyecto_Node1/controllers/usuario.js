//define el controlador de  usuario
var Usuario = require('../models/usuario');


exports.registro = function(req, res, next){  //funcion exportar registro usa tres parametros req,res,next
	var user = new Usuario({  //declara variable user e instancia clase usuario
		nombre : req.body.nombre,  //redirecciona en el doc html el nomre, usuario y pass
		usuario : req.body.usuario,
		password : req.body.pass
	});

	user.save(function (err, usuario){  //función que permite grabar usuario
		if (!err) {
			res.status(201); //devuelve nsje 201
			next();
		}else{
			res.status(400);
			res.send('Ha ocurrido un problema!');
		}
	});
};

// Modelo para el manejo de las imágenes
var models = require('./models'),
Schema = models.Schema;  //define estructura del modelo

var imagenSchema = new Schema({ //define variable imagenSchema e instancia la clase schema
  usuario: String,  //declara usuario e imagen de tipo string
  imagen: String
});

var Imagenes = models.model('Imagen', imagenSchema, 'imagenes');
module.exports = Imagenes;

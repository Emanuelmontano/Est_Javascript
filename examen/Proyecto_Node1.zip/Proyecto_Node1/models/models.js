var mongoose = require('mongoose');  //define variable mongoose y utiliza paquete mongoose
mongoose.connect('mongodb://127.0.0.1:27017/prueba2'); //abre puerto 27017 de mongodb
module.exports = mongoose; 

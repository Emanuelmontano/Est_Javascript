# Ejemplo de Swig

> En este ejemplo hacemos uso de los  *Filters* y *Tags* de Swig.

miApp.controller('controllerInicio', function($scope) {
    $scope.pageClass = 'pagina-inicio';
});

miApp.controller('controllerAcercaDe', function($scope) {
    $scope.pageClass = 'pagina-acercaDe';
});

miApp.controller('controllerContactenos', function($scope) {
    $scope.pageClass = 'pagina-contactenos';
});
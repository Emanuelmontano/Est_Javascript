var express = require('express');
var app = express();

var server = require('http').createServer(app);
var io = require('socket.io')(server);
var path = require('path');
var _ = require('lodash');

var usuarios = [];
var clientes = {};

app.use(express.static(path.join(__dirname)));

app.get('/', function(req, res){
  res.sendFile(__dirname+'/index.html');
});


io.on('connection', function(socket){
  console.log('a user connected');
  
  socket.on('disconnect', function(){
    console.log('user disconnected');
  });

  socket.on('chat message', function(msj){
  	var match = /@([^@]+)@/.exec(msj.mensaje);
  	
  		if (match != null) {
  			var id = _.find(usuarios, { 'nombre': match[1] }).id;
  			console.log(socket.id);
  			//io.sockets.socket(id).emit('chat message', msj);
  			socket.emit('chat message', msj);
  			socket.broadcast.in(id).emit('chat message', msj);
  		}else{

  			io.emit('chat message', msj);
  		}
  });


  socket.on('new user', function(nombre){
	 usuarios.push({id : socket.id, nombre : nombre});
	 //clientes[nombre]  = socket;
  	console.log("Usuarios conectados", JSON.stringify(usuarios));
  	io.emit('new user', usuarios);
  	
  });

});	

server.listen(3000, function(){
	console.log('Servidor corriendo en el puerto 3000');
});


